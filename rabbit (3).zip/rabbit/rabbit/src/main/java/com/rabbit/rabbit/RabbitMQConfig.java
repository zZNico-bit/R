package com.rabbit.rabbit;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String QUEUE_NAME = "mi_cola";

    @Bean
    public Queue miCola() {
        // Crea la cola llamada 'mi_cola_prueba' en RabbitMQ si no existe
        return new Queue(QUEUE_NAME, true);
    }
}