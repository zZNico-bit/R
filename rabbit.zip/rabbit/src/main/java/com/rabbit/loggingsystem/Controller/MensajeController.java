package com.rabbit.loggingsystem.Controller;

import com.rabbit.loggingsystem.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
public class MensajeController {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @PostMapping("/log")
    public String sendLog(@RequestBody LogMessage logMessage) {
        rabbitTemplate.convertAndSend(
            RabbitMQConfig.EXCHANGE_NAME,
            logMessage.getLevel(),
            logMessage.getMessage()
        );
        return "Log enviado: " + logMessage.getMessage();
    }

    public static class LogMessage {
        private String level;
        private String message;

        public String getLevel() { return level; }
        public void setLevel(String level) { this.level = level; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }
}